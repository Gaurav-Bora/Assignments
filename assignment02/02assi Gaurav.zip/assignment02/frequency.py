def count(para):
    a = para.count(input("Enter word:"))
    print(a)

count('''Can you write a whole paragraph without the letter a ? I wouldn't recommend it.
 Honestly, your sentences will sound wrong.
Not just you but everyone else will also notice you are doing something weird. 
 You will wse uncommon words. It's not worth the effort involved .''')

count(''' she never liked cleaning the sink. It was beyond her comprehension how it  got so dirty so quickly .
      It seemed thet she was forced to clean it every other day .
      Even when she was extra careful to keep things clean and orderly , 
      it still ended up looking like a mess in a couple of days . What she didn't know  there was a tiny creatyre living in it
      that didn't like things neat.''')

count(" ")

count(''' Do you really listen when you are talking with someone??? 
      I have a friend who listens in an unforgiving way? She actually takes every word you say as being something important 
      and when ypu have a friend that listens like that , words take a whole new meaning ''')

count('''Barbara had been waiting at the table for twenty minutes .
      It had been twenty long excruciating minutes.
      David had promised that he would be on time today.
      He never was, but he had promised this one time. 
      She had made him repeat the promise multiple times  over the last week until 
      she'd believed his promise. Now she was paying the price.''')


