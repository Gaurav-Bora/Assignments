string = input("Enter name :")
if (string == string[::-1]):
    print(f"{string} True")
else:
    print(f"{string} False")
    
 